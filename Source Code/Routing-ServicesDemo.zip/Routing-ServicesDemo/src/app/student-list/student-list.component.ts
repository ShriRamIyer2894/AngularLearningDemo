import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {

  students : any;
  constructor(private router:Router, private student:StudentService) { }


  ngOnInit(): void {
    this.students=this.student.GetStudentDetails();
  }

  onSelect(student:any){

    this.router.navigate(['/StudentDetail',student.id]);
  }
}
