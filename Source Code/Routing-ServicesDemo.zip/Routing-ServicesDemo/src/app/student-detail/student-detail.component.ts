import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-detail',
  templateUrl: './student-detail.component.html',
  styleUrls: ['./student-detail.component.css']
})
export class StudentDetailComponent implements OnInit {

  studentId:number;
  student:any;
  students = [
    {"id": 1, "name": "Shri Ram"},
    {"id": 2, "name": "Anil"},
    {"id": 3, "name": "Kunwar"},
    {"id": 4, "name": "Selim"},
    {"id": 5, "name": "Aravind"}
  ]
  constructor(private route:ActivatedRoute,private studentService:StudentService) { }

  ngOnInit(): void {
    //this.route.paramMap.subscribe(params=>{
    //  this.studentId=parseInt(params.get('id')!);
    //})
    this.studentId=parseInt(this.route.snapshot.paramMap.get('id')!);
    this.student=this.studentService.GetStudentDetailById(this.studentId);
  }

}
