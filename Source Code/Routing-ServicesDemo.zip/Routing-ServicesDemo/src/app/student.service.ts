import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  students = [
    {"id": 1, "name": "Shri Ram"},
    {"id": 2, "name": "Anil"},
    {"id": 3, "name": "Kunwar"},
    {"id": 4, "name": "Selim"},
    {"id": 5, "name": "Aravind"}
  ]

  constructor() { }

  GetStudentDetails(){
    return this.students;
  }

  GetStudentDetailById(id:number){
    return this.students.find(x=>x.id===id)
  }
}
