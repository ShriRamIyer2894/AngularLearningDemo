import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  @Input() loggedIn:boolean;
  @Output() greetEvent= new EventEmitter();
  name= "Trizetto Provider Solutions"
  constructor() { }

  ngOnInit(): void {
  }
  CallParentGreet(){
    this.greetEvent.emit(this.name);
  }
}
